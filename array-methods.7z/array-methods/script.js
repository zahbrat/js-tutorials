// let array = [1, 2, 3, 4, 5];
// array.push(6)

// let array = ['sophie', 'julia', 'dima']
// array.pop()

// let array = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
// let newArray = array.slice(0, 5)

// console.log(newArray)

// let family = ["Оксана", "Вадим", "Захар", "Ання"];
// let stingFamily = "";
// family.length === 0 ? "Сім'я складається з: " : "Сім'я пуста";

// for (const human of family) {
//   stingFamily += `${ human } `;
// }

// console.log(stingFamily);

//напишіть функцію standardizeStrings, яка прийматиме в себе масив рядків і виводитиме в консоль ці рядки в нижньому регістрі.
//Приклад:
//standardizeStrings(favoriteCities) виведе в консоль
//lisbon
//rome
//milan
//dublin
//Це часте завдання в реальності, оскільки від користувача нам можуть прийти відповіді в найрізноманітніших форматах. Зокрема і з різними літерами 😊 Тому нам потрібно привести рядки в один формат для правильної роботи.

// let favoriteCities = ['ЛіСабон', "рИМ", "МІлан", "дУбЛіН"]

// for (const city of favoriteCities) {
//   console.log(city.toLocaleLowerCase())
// }

// let styles = ['Джаз', 'Блюз'];
// styles.push("Рок-н-ролл");
// styles.splice(1, 1, "Класика");
// console.log(styles.shift(styles[0]))
// styles.splice(0, 0, 'Реп', 'Реггі')
// console.log(styles)

// let someString = "This is some strange string";
// let reversedString = "";

// for (let i = someString.length-1; i >= 0; i--){
//   reversedString += someString[i];
// }

// console.log(reversedString);

// // Напиши скрипт який замінює регістр кожного символа в рядку на протилежний. Наприклад, якщо рядок «JavaScript», то на виході повинно бути «jAVAsCRIPT».

// let string2 = "JavaScript"
// let result = "";

// for (let i = 0; i < string2.length; i++) {
//   if (string2[i] === string2[i].toUpperCase()) {
//     result += string2[i].toLowerCase();
//   }
//   else {
//     result += string2[i].toUpperCase();
//   }
// }

// console.log(result);

// // Напиши скрипт який рахує суму елементів двух масивів.
// const array1 = [5, 10, 15, 20];
// const array2 = [10, 20, 30];
// const arrayConcat = array1.concat(array2);

// let sum = 0;

// for (let i = 0; i < arrayConcat.length; i++) {
//   sum += arrayConcat[i];
// }

// console.log(sum);

//____________________________________________________________

// 1
// for

let arrayNames = ["Мідний Бик", "https://midniy-bichok.tiiny.site/", "https://discord.gg/x5BCngDH", "Midni_bik.aternos.me:29981", "1.12.2"];
let stringResult = "";

for (let i = 0; i < arrayNames.length; i++){
  stringResult += arrayNames[i] + ", "
}

console.log(stringResult);

//join()

//______________________________________

stringResult = arrayNames.join(", ");

console.log(stringResult);

//2

const cards = [
  "Карточка-1",
  "Карточка-2",
  "Карточка-3",
  "Карточка-4",
  "Карточка-5",
];

// ____________________________________________

//3

const cardToRemove = "Карточка-3";
cards.splice(cards.indexOf(cardToRemove), 1);

console.log(cards);

//____________________________________________

//4

const cardToInsert = "Карточка-6";
cards.splice(4, 0, cardToInsert);

console.log(cards);

//____________________________________________

//5

const cardToUpdate = "Карточка-4";
cards.splice(cards.indexOf(cardToUpdate), 1, "Карточка-4 (оновлена)");

console.log(cards);