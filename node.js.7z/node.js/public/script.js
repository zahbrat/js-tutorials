const btn = document.getElementById("btn");
btn.addEventListener("click", () => alert("Уляя!!"));
