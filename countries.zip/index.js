import debounce from "lodash.debounce";
import { alert, notice } from "@pnotify/core";
import "@pnotify/core/dist/PNotify.css";
import "@pnotify/core/dist/BrightTheme.css";
import countryTpl from "./templates/country.hbs";
import countriesListTpl from "./templates/countries-list.hbs";

const input = document.querySelector("#search-box");
const resultsContainer = document.querySelector("#results");
const API_URL = "https://restcountries.com/v2/name/";

const fetchCountries = async (name) => {
  try {
    const response = await fetch(`${API_URL}${name}`);
    if (!response.ok) throw new Error("Country not found");
    return response.json();
  } catch (error) {
    alert({ text: "Country not found", type: "error" });
  }
};

const handleInput = debounce(async (event) => {
  const query = event.target.value.trim();
  resultsContainer.innerHTML = "";
  if (!query) return;

  const countries = await fetchCountries(query);
  if (!countries) return;

  if (countries.length > 10) {
    notice({
      text: "Too many matches found. Please enter a more specific name.",
    });
  } else if (countries.length > 1) {
    resultsContainer.innerHTML = countriesListTpl({ countries });
  } else {
    resultsContainer.innerHTML = countryTpl(countries[0]);
  }
}, 500);

input.addEventListener("input", handleInput);
